package com.proyek.jtk.model

import com.proyek.jtk.R

object FakeRewardDataSource {
    val dummyRewards = listOf(
        Reward(1, R.drawable.reward_13, "Reward 1", 200),
        Reward(2, R.drawable.reward_13, "Reward 2", 300),
        Reward(3, R.drawable.reward_13, "Reward 3", 400),
        Reward(4, R.drawable.reward_13, "Reward 4", 500),
        Reward(5, R.drawable.reward_13, "Reward 5", 600),
        Reward(6, R.drawable.reward_13, "Reward 6", 700),
        Reward(7, R.drawable.reward_13, "Reward 7", 800),
        Reward(8, R.drawable.reward_13, "Reward 8", 900),
        Reward(9, R.drawable.reward_13, "Reward 9", 1000),

    )
}